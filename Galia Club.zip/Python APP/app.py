from flask import Flask, render_template, request, jsonify
import os, json

app = Flask(__name__)
DATA_FOLDER = os.path.join(os.path.dirname(__file__), 'data')

def get_file(datatype):
    return os.path.join(DATA_FOLDER, f"{datatype}.json")

def load_data(datatype):
    path = get_file(datatype)
    if os.path.exists(path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return []

def save_data(datatype, data):
    path = get_file(datatype)
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/api/<datatype>', methods=['GET', 'POST'])
def handle_data(datatype):
    if datatype not in ['athletes', 'coaches', 'groups', 'payments']:
        return jsonify({'error': 'Invalid data type'}), 400

    if request.method == 'GET':
        return jsonify(load_data(datatype))

    if request.method == 'POST':
        data = request.get_json()
        save_data(datatype, data)
        return jsonify({'status': 'success'})

if __name__ == '__main__':
    os.makedirs(DATA_FOLDER, exist_ok=True)
    for file in ['athletes', 'coaches', 'groups', 'payments']:
        if not os.path.exists(get_file(file)):
            save_data(file, [])
    app.run(debug=True)
